import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import 'swiper/css';
import 'swiper/css/autoplay';
import { VscTriangleRight, VscTriangleDown, VscTriangleUp } from "react-icons/vsc";
import { FaSearch, FaSearchPlus, FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram, FaPinterestP } from "react-icons/fa";
import { TiTick } from "react-icons/ti";

import Header from '../components/Header';
import Footer from '../components/Footer';

const Agent = () => {
  const [filters, setFilters] = useState({
    status: "Any",
    location: "All Locations",
    type: "All Types",
  });

  const [openDropdown, setOpenDropdown] = useState(null);

  const dropdowns = [
    {
      label: "Property Status",
      name: "status",
      options: ["Any", "For Sale", "For Rent"],
    },
    {
      label: "Location",
      name: "location",
      options: ["All Locations", "Karachi", "Lahore", "Islamabad"],
    },
    {
      label: "Property Type",
      name: "type",
      options: [
        "All Types",
        { group: "Commercial", items: ["Office", "Shop"] },
        {
          group: "Residential",
          items: ["Apartment", "Apartment Building", "Condominium", "Single Family", "Villa"],
        },
      ],
    },
  ];

  const handleSelect = (name, value) => {
    setFilters({ ...filters, [name]: value });
    setOpenDropdown(null);
  };

  const Posts = [
    {
      id: 1,
      title: "Modern Villa Dubai",
      price: 950000,
      beds: { count: 4 },
      baths: { count: 2 },
      sqft: { count: 3600 },
      sale: "Trendy",
      camera: "5",
      video: "3",
      image: "https://www.marbella-ev.com/wp-content/uploads/2021/03/Most-Luxury-Villla-in-Marbella.jpg",
    },
    {
      id: 2,
      title: "Luxury Home in Clifton",
      price: 1250000,
      beds: { count: 4 },
      baths: { count: 2 },
      sqft: { count: 3600 },
      sale: "Trendy",
      camera: "6",
      video: "4",
      image: "https://www.homeportal.world/wp-content/uploads/2025/03/02-copia-scaled.jpg",
    },
    {
      id: 3,
      title: "Modern Villa Dubai",
      price: 950000,
      beds: { count: 4 },
      baths: { count: 2 },
      sqft: { count: 3600 },
      sale: "Trendy",
      camera: "5",
      video: "3",
      image: "https://www.marbella-ev.com/wp-content/uploads/2021/03/Most-Luxury-Villla-in-Marbella.jpg",
    },
    {
      id: 4,
      title: "Luxury Home in Clifton",
      price: 1250000,
      beds: { count: 4 },
      baths: { count: 2 },
      sqft: { count: 3600 },
      sale: "Trendy",
      camera: "6",
      video: "4",
      image: "https://www.homeportal.world/wp-content/uploads/2025/03/02-copia-scaled.jpg",
    },
    {
      id: 5,
      title: "Elegant Bungalow in DHA",
      price: 780000,
      beds: { count: 4 },
      baths: { count: 2 },
      sqft: { count: 3600 },
      sale: "Trendy",
      camera: "3",
      video: "2",
      image: "https://i.pinimg.com/originals/60/f6/e7/60f6e7b8d5a74d59b16f29ad5764d952.jpg",
    },
    {
      id: 6,
      title: "Elegant Bungalow in DHA",
      price: 780000,
      beds: { count: 4 },
      baths: { count: 2 },
      sqft: { count: 3600 },
      sale: "Trendy",
      camera: "3",
      video: "2",
      image: "https://i.pinimg.com/originals/60/f6/e7/60f6e7b8d5a74d59b16f29ad5764d952.jpg",
    },
  ];

  const getMapSrc = (location) => {
    const query = encodeURIComponent(location === "All Locations" ? "Pakistan" : location);
    return `https://maps.google.com/maps?q=${query}&t=&z=13&ie=UTF8&iwloc=&output=embed`;
  };

  return (
    <>
      <Header />
      <section className="py-10">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold mb-6">Our Properties</h1>

          {/* Dropdown Filters */}
          <div className="flex gap-4 mb-6">
            {dropdowns.map((dd, idx) => (
              <div key={idx} className="relative">
                <button
                  onClick={() => setOpenDropdown(openDropdown === dd.name ? null : dd.name)}
                  className="border px-4 py-2 rounded flex items-center justify-between w-52"
                >
                  {filters[dd.name]}
                  {openDropdown === dd.name ? <VscTriangleUp /> : <VscTriangleDown />}
                </button>
                {openDropdown === dd.name && (
                  <div className="absolute bg-white border mt-1 w-full z-10">
                    {dd.options.map((opt, i) =>
                      typeof opt === "string" ? (
                        <div
                          key={i}
                          onClick={() => handleSelect(dd.name, opt)}
                          className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                        >
                          {opt}
                        </div>
                      ) : (
                        <div key={i}>
                          <div className="font-semibold px-4 py-2">{opt.group}</div>
                          {opt.items.map((item, j) => (
                            <div
                              key={j}
                              onClick={() => handleSelect(dd.name, item)}
                              className="px-6 py-2 hover:bg-gray-100 cursor-pointer"
                            >
                              {item}
                            </div>
                          ))}
                        </div>
                      )
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Property Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Posts.map((post) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
                className="bg-white rounded-xl shadow-lg overflow-hidden group hover:shadow-2xl transition-all duration-300"
              >
                <img src={post.image} alt={post.title} className="w-full h-64 object-cover" />
                <div className="p-4">
                  <h2 className="font-bold text-xl">{post.title}</h2>
                  <p className="text-blue-500 font-semibold">${post.price.toLocaleString()}</p>
                  <div className="flex gap-4 mt-2">
                    <span>{post.beds.count} Beds</span>
                    <span>{post.baths.count} Baths</span>
                    <span>{post.sqft.count} sqft</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};

export default Agent;
